class MapboxConfig {
  static const String accessToken = String.fromEnvironment('MAPBOX_TOKEN');
}